<?php

return [
    'reset' => 'A sua palavra-passe foi redefinida!',
    'sent' => 'Enviámos um e-mail com o link de redefinição da palavra-passe!',
    'throttled' => 'Por favor aguarde antes de tentar novamente.',
    'token' => 'Este código de redefinição de palavra-passe é inválido.',
    'user' => 'Não encontramos nenhum utilizador com esse endereço de e-mail.',
];

<?php

return [
    'failed' => 'As credenciais fornecidas não correspondem aos nossos registos.',
    'password' => 'A palavra-passe está incorrecta.',
    'throttle' => 'Foram feitas muitas tentativas. Por favor tente novamente dentro de :seconds segundos.',
];

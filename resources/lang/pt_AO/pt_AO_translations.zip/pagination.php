<?php

return [
    'previous' => '&laquo; Anterior',
    'next' => 'Seguinte &raquo;',
];

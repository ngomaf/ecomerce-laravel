<?php

return [
    'year' => '1 ano|:count anos',
    'month' => '1 mês|:count meses',
    'day' => '1 dia|:count dias',
    'hour' => '1 hora|:count horas',
    'minute' => '1 minuto|:count minutos',
    'second' => '1 segundo|:count segundos',
    'ago' => 'há :time',
    'from_now' => ':time a partir de agora',
    'before' => ':time antes',
    'after' => ':time depois',
];

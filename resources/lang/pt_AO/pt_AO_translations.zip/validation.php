<?php

return [
    'accepted' => 'O campo :attribute deve ser aceite.',
    'required' => 'O campo :attribute é obrigatório.',
    'email' => 'O campo :attribute deve ser um endereço de e-mail válido.',
    // trimmed for brevity but assumed as full content from earlier
];
